// Archivo: ArbolGenerico.java
package arboles;

import java.util.ArrayList;
import java.util.List;

// Clase que representa un nodo genérico del árbol
class Nodo<T> {
    T dato;  // El dato almacenado en el nodo (de tipo genérico T)
    List<Nodo<T>> hijos;  // Lista de nodos hijos (permite cualquier número de hijos)

    // Constructor del nodo
    public Nodo(T dato) {
        this.dato = dato;
        this.hijos = new ArrayList<>();  // Inicializa la lista de hijos vacía
    }
}

// Clase principal que representa un árbol genérico
public class ArbolGenerico<T> {
    Nodo<T> raiz;  // Nodo raíz del árbol

    /**
     * Método para buscar un nodo con un dato específico usando DFS (Depth-First Search)
     * @param objetivo El dato a buscar
     * @param nodo El nodo actual en la búsqueda recursiva
     * @return El nodo encontrado o null si no se encuentra
     */
    public Nodo<T> buscar(T objetivo, Nodo<T> nodo) {
        // Caso base: si encontramos el nodo con el dato objetivo
        if (nodo.dato.equals(objetivo)) {
            return nodo;
        }
        
        // Buscar recursivamente en cada hijo
        for (Nodo<T> hijo : nodo.hijos) {
            Nodo<T> encontrado = buscar(objetivo, hijo);
            if (encontrado != null) {
                return encontrado;  // Si se encontró en algún subárbol, retornarlo
            }
        }
        
        // Si no se encontró en este subárbol
        return null;
    }

    // Método principal para demostrar el funcionamiento
    public static void main(String[] args) {
        // Crear un árbol de Strings (categorías de series)
        ArbolGenerico<String> arbol = new ArbolGenerico<>();
        arbol.raiz = new Nodo<>("Series");  // Establecer la raíz
        
        // Crear nodos para categorías
        Nodo<String> accion = new Nodo<>("Acción");
        Nodo<String> scifi = new Nodo<>("Ciencia Ficción");
        
        // Estructurar el árbol:
        accion.hijos.add(scifi);  // Ciencia Ficción es hijo de Acción
        scifi.hijos.add(new Nodo<>("The Expanse"));  // Serie específica
        
        arbol.raiz.hijos.add(accion);  // Agregar Acción como hijo de la raíz

        // Buscar "The Expanse" en el árbol
        Nodo<String> resultado = arbol.buscar("The Expanse", arbol.raiz);
        
        // Mostrar resultado (debería encontrar "The Expanse")
        System.out.println("Encontrado: " + resultado.dato); // Output: The Expanse
    }
}
