// Archivo: ArbolGenerico.java
package arboles;

import java.util.ArrayList;
import java.util.List;

class Nodo<T> {
    T dato;
    List<Nodo<T>> hijos;

    public Nodo(T dato) {
        this.dato = dato;
        hijos = new ArrayList<>();
    }
}

public class ArbolGenerico<T> {
    Nodo<T> raiz;

    // Buscar un nodo (DFS)
    public Nodo<T> buscar(T objetivo, Nodo<T> nodo) {
        if (nodo.dato.equals(objetivo)) return nodo;
        for (Nodo<T> hijo : nodo.hijos) {
            Nodo<T> encontrado = buscar(objetivo, hijo);
            if (encontrado != null) return encontrado;
        }
        return null;
    }

    public static void main(String[] args) {
        ArbolGenerico<String> arbol = new ArbolGenerico<>();
        arbol.raiz = new Nodo<>("Series");
        
        Nodo<String> accion = new Nodo<>("Acción");
        Nodo<String> scifi = new Nodo<>("Ciencia Ficción");
        accion.hijos.add(scifi);
        scifi.hijos.add(new Nodo<>("The Expanse"));
        
        arbol.raiz.hijos.add(accion);

        // Buscar "The Expanse"
        Nodo<String> resultado = arbol.buscar("The Expanse", arbol.raiz);
        System.out.println("Encontrado: " + resultado.dato); // Output: The Expanse
    }
}
