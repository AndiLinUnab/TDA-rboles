// Archivo: ArbolAVL.java
package arboles;

class NodoAVL {
    int valor, altura;
    NodoAVL izquierda, derecha;

    NodoAVL(int valor) {
        this.valor = valor;
        altura = 1;
    }
}

public class ArbolAVL {
    NodoAVL raiz;

    // Calcular altura
    int altura(NodoAVL nodo) {
        return (nodo == null) ? 0 : nodo.altura;
    }

    // Rotación simple a la derecha
    NodoAVL rotarDerecha(NodoAVL y) {
        NodoAVL x = y.izquierda;
        NodoAVL T2 = x.derecha;

        x.derecha = y;
        y.izquierda = T2;

        y.altura = Math.max(altura(y.izquierda), altura(y.derecha)) + 1;
        x.altura = Math.max(altura(x.izquierda), altura(x.derecha)) + 1;

        return x;
    }

    // Insertar con balanceo automático
    NodoAVL insertar(NodoAVL nodo, int valor) {
        if (nodo == null) return new NodoAVL(valor);

        if (valor < nodo.valor)
            nodo.izquierda = insertar(nodo.izquierda, valor);
        else if (valor > nodo.valor)
            nodo.derecha = insertar(nodo.derecha, valor);
        else
            return nodo;

        nodo.altura = 1 + Math.max(altura(nodo.izquierda), altura(nodo.derecha));

        int balance = altura(nodo.izquierda) - altura(nodo.derecha);

        // Casos de rotación
        if (balance > 1 && valor < nodo.izquierda.valor)
            return rotarDerecha(nodo);

        // ... (otros casos de rotación aquí)

        return nodo;
    }

    public static void main(String[] args) {
        ArbolAVL arbol = new ArbolAVL();
        arbol.raiz = arbol.insertar(arbol.raiz, 10);
        arbol.raiz = arbol.insertar(arbol.raiz, 20);
        arbol.raiz = arbol.insertar(arbol.raiz, 30); // Se auto-balancea
        System.out.println("Raíz después de rotación: " + arbol.raiz.valor); // Output: 20
    }
}
