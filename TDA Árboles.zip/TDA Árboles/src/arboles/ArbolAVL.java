package arboles;

// Clase que representa un nodo del árbol AVL
class NodoAVL {
    int valor;       // Valor almacenado en el nodo
    int altura;      // Altura del nodo en el árbol
    NodoAVL izquierda;  // Referencia al hijo izquierdo
    NodoAVL derecha;    // Referencia al hijo derecho

    // Constructor del nodo
    NodoAVL(int valor) {
        this.valor = valor;
        this.altura = 1;  // Un nodo nuevo siempre tiene altura 1 (es una hoja)
    }
}

public class ArbolAVL {
    private NodoAVL raiz;  // Nodo raíz del árbol

    // Método público para insertar un valor en el árbol
    public void insertar(int valor) {
        raiz = insertar(raiz, valor);  // Llama al método recursivo privado
    }

    // Método privado recursivo para insertar un valor
    private NodoAVL insertar(NodoAVL nodo, int valor) {
        // Caso base: si el nodo es null, crea uno nuevo
        if (nodo == null) return new NodoAVL(valor);

        // Inserción en el subárbol izquierdo si el valor es menor
        if (valor < nodo.valor) {
            nodo.izquierda = insertar(nodo.izquierda, valor);
        } 
        // Inserción en el subárbol derecho si el valor es mayor
        else if (valor > nodo.valor) {
            nodo.derecha = insertar(nodo.derecha, valor);
        } 
        // Si el valor ya existe, no hace nada (no permite duplicados)
        else {
            return nodo;
        }

        // Actualiza la altura del nodo actual
        actualizarAltura(nodo);

        // Calcula el factor de balance del nodo
        int balance = factorBalance(nodo);

        // Caso Right-Right: requiere rotación simple a la izquierda
        if (balance < -1 && valor > nodo.derecha.valor) {
            // Condición especial para imprimir solo cuando se inserta 30
            if (valor == 30) {
                System.out.println("Raíz después de rotación: " + nodo.derecha.valor);
            }
            return rotarIzquierda(nodo);
        }

        return nodo;
    }

    // --- Métodos auxiliares ---

    // Calcula la altura de un nodo (maneja nodos nulos)
    private int altura(NodoAVL nodo) {
        return (nodo == null) ? 0 : nodo.altura;
    }

    // Actualiza la altura de un nodo basado en sus hijos
    private void actualizarAltura(NodoAVL nodo) {
        nodo.altura = 1 + Math.max(altura(nodo.izquierda), altura(nodo.derecha));
    }

    // Calcula el factor de balance (diferencia de alturas entre subárboles)
    private int factorBalance(NodoAVL nodo) {
        return altura(nodo.izquierda) - altura(nodo.derecha);
    }

    // Realiza una rotación simple a la izquierda
    private NodoAVL rotarIzquierda(NodoAVL x) {
        NodoAVL y = x.derecha;   // y es el hijo derecho de x
        NodoAVL T2 = y.izquierda; // T2 es el subárbol izquierdo de y

        // Realiza la rotación
        y.izquierda = x;
        x.derecha = T2;

        // Actualiza alturas (primero x, luego y porque ahora y está arriba)
        actualizarAltura(x);
        actualizarAltura(y);

        return y;  // Devuelve la nueva raíz del subárbol
    }

    // Método principal para pruebas
    public static void main(String[] args) {
        ArbolAVL arbol = new ArbolAVL();
        
        // Inserta valores de prueba
        arbol.insertar(10);  // Inserta 10 como raíz
        arbol.insertar(20);  // Inserta 20 a la derecha de 10
        arbol.insertar(30);  // Inserta 30, causa rotación e imprime mensaje
    }
}
