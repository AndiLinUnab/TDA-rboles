// Archivo: ArbolBinario.java
package arboles;

// Clase que representa un nodo del árbol binario
class Nodo {
    int valor;        // Valor almacenado en el nodo
    Nodo izquierda;   // Referencia al hijo izquierdo
    Nodo derecha;     // Referencia al hijo derecho

    // Constructor del nodo
    public Nodo(int item) {
        valor = item;           // Asigna el valor al nodo
        izquierda = derecha = null;  // Inicializa los hijos como nulos
    }
}

// Clase principal que representa el árbol binario de búsqueda
public class ArbolBinario {
    Nodo raiz;  // Nodo raíz del árbol

    // Método público para insertar un valor en el árbol
    void insertar(int valor) {
        raiz = insertarRec(raiz, valor);  // Llama al método recursivo de inserción
    }

    // Método recursivo privado para insertar un valor
    Nodo insertarRec(Nodo raiz, int valor) {
        // Caso base: si el nodo actual es nulo, crea un nuevo nodo
        if (raiz == null) {
            raiz = new Nodo(valor);
            return raiz;
        }
        
        // Si el valor es menor que el valor del nodo actual, inserta en el subárbol izquierdo
        if (valor < raiz.valor)
            raiz.izquierda = insertarRec(raiz.izquierda, valor);
        // Si el valor es mayor que el valor del nodo actual, inserta en el subárbol derecho
        else if (valor > raiz.valor)
            raiz.derecha = insertarRec(raiz.derecha, valor);
        
        // Retorna el nodo (modificado o no)
        return raiz;
    }

    // Método para recorrido in-orden (muestra los valores ordenados)
    void inOrden(Nodo raiz) {
        if (raiz != null) {
            inOrden(raiz.izquierda);      // Recorre el subárbol izquierdo
            System.out.print(raiz.valor + " "); // Visita el nodo actual
            inOrden(raiz.derecha);        // Recorre el subárbol derecho
        }
    }

    // Método principal para probar la implementación
    public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();  // Crea un nuevo árbol
        
        // Inserta valores en el árbol
        arbol.insertar(50);  // Inserta 50 como raíz
        arbol.insertar(30);  // Inserta 30 (izquierda de 50)
        arbol.insertar(70);  // Inserta 70 (derecha de 50)
        arbol.insertar(20);  // Inserta 20 (izquierda de 30)
        arbol.insertar(40);  // Inserta 40 (derecha de 30)

        // Realiza y muestra el recorrido in-orden
        System.out.println("Recorrido In-Orden:");
        arbol.inOrden(arbol.raiz);  // Output: 20 30 40 50 70
    }
}
